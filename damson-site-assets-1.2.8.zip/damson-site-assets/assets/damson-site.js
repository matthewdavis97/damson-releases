/* Damson site JS, delivered by the "Damson Site Assets" plugin (front end only).
   Contains: builder guard + helpers, v8 motion, v8.1 bento tiles, v8.3 forms, v8.5 health check.
   Every part respects prefers-reduced-motion and does nothing inside the Divi builder. */
(function(){
 function has(el,c){return !!(el&&el.classList&&el.classList.contains(c))}
 function inBuilder(){
  var d=document.documentElement,b=document.body,s=location.search||'';
  if(window.self!==window.top)return true;                       /* Divi 5 builder / previews render the page in an iframe */
  if(/(^|[?&])(et_fb|et_pb_preview|et_tb|et_bfb|app_window|et_block_layout_preview)=/.test(s))return true;
  if(has(d,'et-fb')||has(b,'et-fb')||has(b,'et-fb-root-ancestor')||has(b,'et-bfb')||has(d,'et-fb-preview--desktop'))return true;
  if(window.ETBuilderBackend||window.ET_Builder||window.et_fb_options)return true;
  return false}
 if(inBuilder()){window.__dmBuilder=window.__dm8=window.__dm81b=window.__dm83=window.__dm84=window.__dm85=1;return}
 var still=!!(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches);
 function ready(f){document.readyState==='loading'?document.addEventListener('DOMContentLoaded',f):f()}
 ready(function(){if(inBuilder()){window.__dmBuilder=1;return}
  /* overflow clip so sticky columns work (replaces #page-container has() rules) */
  var pc=document.getElementById('page-container');
  if(pc&&document.querySelector('.dm-sticky,.dm-ct-form,.dm-hc-req'))pc.classList.add('dm-clip');
  /* smooth scroll to the form anchors (replaces html has() rules) */
  if(!still&&(document.getElementById('get-in-touch')||document.getElementById('request')))document.documentElement.classList.add('dm-smooth');
  /* health check: hovering one of the six areas lights its example results card (replaces hover has() rules) */
  document.querySelectorAll('.dm-areas').forEach(function(row){
   row.querySelectorAll('.dm-area-list .et_pb_blurb').forEach(function(bl,i){var c='dm-hl-'+(i+1);
    bl.addEventListener('mouseenter',function(){row.classList.add(c)});bl.addEventListener('mouseleave',function(){row.classList.remove(c)})})})
 })
})();
/* ---------- v8 ---------- */
/* Damson v8 homepage motion. No square brackets anywhere, so it is also safe inside a Divi Code module.
   Skips itself inside the Divi Visual Builder and respects prefers-reduced-motion. */
(function(){if(window.__dm8)return;window.__dm8=1;
function ready(f){document.readyState==='loading'?document.addEventListener('DOMContentLoaded',f):f()}
function inVB(){var d=document.documentElement,b=document.body;return d.classList.contains('et-fb')||(b&&(b.classList.contains('et-fb')||b.classList.contains('et-fb-root-ancestor')))||location.search.indexOf('et_fb=1')>-1}
ready(function(){if(inVB())return;
var still=!!(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches);
var IO=('IntersectionObserver' in window);
function vh(){return window.innerHeight||document.documentElement.clientHeight}
function each(sel,f,root){(root||document).querySelectorAll(sel).forEach(f)}

/* 1. scroll reveal: only things below the fold, staggered within each row */
if(!still&&IO){
 var io=new IntersectionObserver(function(es){es.forEach(function(e){if(!e.isIntersecting)return;var el=e.target;io.unobserve(el);el.classList.add('is-in');var d=parseInt(el.style.getPropertyValue('--d'),10)||0;setTimeout(function(){el.classList.remove('dm-rv');el.classList.remove('is-in');el.style.removeProperty('--d')},950+d)})},{rootMargin:'0px 0px -8% 0px',threshold:0.12});
 each('.dm-s:not(.dm-hero):not(.dm-mq-sec) .et_pb_row:not(.dm-cta) > .et_pb_column:not(.dm-panel) > .et_pb_module, .dm-s .et_pb_column.dm-panel, .dm-s .et_pb_row.dm-cta',function(el){
  if(el.closest('.dm-hero,.dm-mq-sec'))return;
  if(el.getBoundingClientRect().top<vh()*0.92)return;
  var row=el.closest('.et_pb_row');var n=row?(row.__dmN=(row.__dmN||0)+1):1;
  el.style.setProperty('--d',Math.min((n-1)*90,450)+'ms');el.classList.add('dm-rv');io.observe(el)})}

/* 2. card spotlight follows the pointer */
each('.dm-s .dm-card',function(c){c.addEventListener('pointermove',function(e){var r=c.getBoundingClientRect();c.style.setProperty('--mx',(e.clientX-r.left)+'px');c.style.setProperty('--my',(e.clientY-r.top)+'px')})});

/* 3. process timeline fills as you scroll */
each('.dm-s .dm-vtl',function(tl){var steps=tl.querySelectorAll('.dm-st');tl.classList.add('dm-vtl-js');var q=0;
 function tick(){var r=tl.getBoundingClientRect(),mid=vh()*0.62,p=(mid-r.top-28)/Math.max(1,r.height-84);p=Math.max(0,Math.min(1,p));tl.style.setProperty('--dm-fill',still?1:p.toFixed(4));steps.forEach(function(s){s.classList.toggle('is-on',still||s.getBoundingClientRect().top+28<=mid)})}
 addEventListener('scroll',function(){if(!q){q=1;requestAnimationFrame(function(){q=0;tick()})}},{passive:true});addEventListener('resize',tick);tick()});

/* 4. before / after slider (+ one gentle hint sweep the first time it is seen) */
each('.dm-ba',function(ba){var rg=ba.querySelector('.dm-ba-range');if(!rg)return;function set(v){ba.style.setProperty('--pos',v+'%')}
 rg.addEventListener('input',function(){ba.classList.add('is-used');set(rg.value)});set(rg.value);
 if(still||!IO)return;var o=new IntersectionObserver(function(es){es.forEach(function(e){if(!e.isIntersecting)return;o.disconnect();var t0=0;
  function step(ts){if(ba.classList.contains('is-used'))return;if(!t0)t0=ts;var k=(ts-t0)/2400;if(k>=1){set(50);return}set((50-Math.sin(k*Math.PI*2)*24*(1-k*0.4)).toFixed(2));requestAnimationFrame(step)}
  setTimeout(function(){requestAnimationFrame(step)},400)})},{threshold:0.55});o.observe(ba)});

/* 5. sample report: rings and numbers count up when it comes into view */
each('.dm-rep',function(rep){if(still||!IO)return;var nums=rep.querySelectorAll('.dm-ring span');rep.classList.add('is-wait');nums.forEach(function(n){n.textContent='0'});
 var o=new IntersectionObserver(function(es){es.forEach(function(e){if(!e.isIntersecting)return;o.disconnect();setTimeout(function(){rep.classList.remove('is-wait');rep.classList.add('is-on');var t0=performance.now();
  function run(now){var k=Math.min(1,(now-t0)/1600),ez=1-Math.pow(1-k,3);nums.forEach(function(n){n.textContent=Math.round(ez*parseInt(n.getAttribute('data-n'),10))});if(k<1)requestAnimationFrame(run)}requestAnimationFrame(run)},300)})},{threshold:0.35});o.observe(rep)});
})})();
/* ---------- v8.1 ---------- */
/* Damson v8.1 option B: bento tiles. Add AFTER the v8 script. No square brackets. */
(function(){if(window.__dm81b)return;window.__dm81b=1;
function ready(f){document.readyState==='loading'?document.addEventListener('DOMContentLoaded',f):f()}
function inVB(){var d=document.documentElement,b=document.body;return d.classList.contains('et-fb')||(b&&(b.classList.contains('et-fb')||b.classList.contains('et-fb-root-ancestor')))||location.search.indexOf('et_fb=1')>-1}
ready(function(){if(inVB())return;var tiles=document.querySelectorAll('.dm-tile');if(!tiles.length)return;document.documentElement.classList.add('dm-vg-js');
 if(!('IntersectionObserver' in window)){tiles.forEach(function(t){t.classList.add('is-live')});return}
 var io=new IntersectionObserver(function(es){es.forEach(function(e){e.target.classList.toggle('is-live',e.isIntersecting)})},{threshold:0.25});
 tiles.forEach(function(t){io.observe(t)})})})();
/* ---------- v8.3 ---------- */
/* Damson v8.3 forms: progress meter and field ticks on any .dm-formcard, plus the "What happens next" timeline.
   No square brackets, safe in Theme Options > Integration (body) after the v8 script, or in a Code module. */
(function(){if(window.__dm83)return;window.__dm83=1;
function ready(f){document.readyState==='loading'?document.addEventListener('DOMContentLoaded',f):f()}
ready(function(){var d=document.documentElement,b=document.body;if(d.classList.contains('et-fb')||b.classList.contains('et-fb')||location.search.indexOf('et_fb=1')>-1)return;
var still=!!(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches);
/* 1. progress meter + ticks */
document.querySelectorAll('.dm-formcard').forEach(function(card){var form=card.querySelector('.dm-form');var fp=card.querySelector('.dm-fp');if(!form)return;
 var fields=form.querySelectorAll('.et_pb_contact_field:not(.et_pb_contact_right)');var n=card.querySelector('.dm-fp-n');var bar=card.querySelector('.dm-fp-bar i');
 function filled(el){var v=(el.value||'').trim();if(!v)return false;if(el.getAttribute('data-field_type')==='email')return /^\S+@\S+\.\S+$/.test(v);return true}
 function upd(){var done=0,total=0,need=0,req=true;fields.forEach(function(f){var el=f.querySelector('input,textarea,select');if(!el)return;total++;var ok=filled(el);if(ok)done++;f.classList.toggle('is-done',ok);if(el.getAttribute('data-required_mark')==='required'){need++;if(!ok)req=false}});
  if(fp){fp.classList.add('is-live');if(bar)bar.style.setProperty('--p',total?Math.max(.04,done/total).toFixed(3):0);if(n)n.textContent=done===0?(need+' required, '+(total-need)+' optional'):(done+' of '+total+' answered')}
  form.classList.toggle('is-ready',req)}
 form.addEventListener('input',upd);form.addEventListener('change',upd);upd()});
/* 2. timeline draws in when it scrolls into view */
var tl=document.querySelectorAll('.dm-s .dm-next');if(still||!('IntersectionObserver' in window))return;
var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('is-on');io.unobserve(e.target)}})},{threshold:.35});
tl.forEach(function(t){t.classList.add('dm-next-js');requestAnimationFrame(function(){io.observe(t)})})})})();
/* ---------- v8.5 ---------- */
/* Damson v8.5 health check: example results tick in, three-step line draws, mock report pages take turns at the front.
   Does nothing in the builder or with reduced motion (everything then shows finished and still). */
(function(){if(window.__dm85)return;window.__dm85=1;
function ready(f){document.readyState==='loading'?document.addEventListener('DOMContentLoaded',f):f()}
ready(function(){var d=document.documentElement,b=document.body;if(d.classList.contains('et-fb')||b.classList.contains('et-fb')||location.search.indexOf('et_fb=1')>-1)return;
if((window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches)||!('IntersectionObserver' in window))return;
var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('is-on');io.unobserve(e.target)}})},{threshold:.3});
function arm(sel,cls){document.querySelectorAll(sel).forEach(function(el){if(el.getBoundingClientRect().top<(window.innerHeight||0)*.75){el.classList.add('is-on');return}el.classList.add(cls);requestAnimationFrame(function(){io.observe(el)})})}
document.querySelectorAll('.dm-ck-card').forEach(function(c){c.style.setProperty('--dm-ck-h',(c.offsetHeight+10)+'px')});
arm('.dm-s .dm-htl','dm-htl-js');arm('.dm-ck','dm-ck-js');
/* report pages: every few seconds the front page tucks behind and the next comes forward (pauses on hover / off screen) */
document.querySelectorAll('.dm-rp-deck').forEach(function(deck){
 var pg=Array.prototype.slice.call(deck.querySelectorAll('.dm-rp-pg'));if(pg.length<2)return;
 var order=pg.map(function(_,i){return i}),seen=false,hover=false;
 function apply(){pg.forEach(function(p){for(var k=0;k<pg.length;k++)p.classList.remove('dm-rp-at'+k)});order.forEach(function(ix,k){pg[ix].classList.add('dm-rp-at'+k)})}
 function step(){var out=pg[order.shift()];order.push(pg.indexOf(out));
  pg.forEach(function(p){p.classList.remove('dm-rp-out','dm-rp-in')});void out.offsetWidth;out.classList.add('dm-rp-out');pg[order[0]].classList.add('dm-rp-in');apply()}
 apply();
 new IntersectionObserver(function(es){seen=es[0].isIntersecting},{threshold:.35}).observe(deck);
 deck.addEventListener('mouseenter',function(){hover=true});deck.addEventListener('mouseleave',function(){hover=false});
 deck.addEventListener('click',step);
 setInterval(function(){if(seen&&!hover&&!document.hidden)step()},4200)})
})})();

;
/* v1.1.2  Case study pages (.dm-cs): count-up results, long-page pan on scroll, hero tilt.
   Skips itself inside the Divi builder; with reduced motion everything shows finished and still. */
(function(){if(window.__dmcs)return;window.__dmcs=1;
function ready(f){document.readyState==='loading'?document.addEventListener('DOMContentLoaded',f):f()}
function inVB(){var d=document.documentElement,b=document.body;if(window.self!==window.top)return true;return d.classList.contains('et-fb')||(b&&(b.classList.contains('et-fb')||b.classList.contains('et-fb-root-ancestor')))||/et_fb=1/.test(location.search)}
ready(function(){if(inVB()||!document.querySelector('.dm-cs'))return;
var still=!!(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches);
var IO=('IntersectionObserver' in window);
function each(sel,f){document.querySelectorAll(sel).forEach(f)}
function vh(){return window.innerHeight||document.documentElement.clientHeight}
/* 1. count-up: <span class="dm-cs-num" data-from="73" data-to="99" data-dp="0">99</span> */
if(!still&&IO){
 var fmt=function(v,dp){return dp>0?v.toFixed(dp):String(Math.round(v))};
 var cio=new IntersectionObserver(function(es){es.forEach(function(e){if(!e.isIntersecting)return;cio.unobserve(e.target);var el=e.target,a=parseFloat(el.getAttribute('data-from')),b=parseFloat(el.getAttribute('data-to')),dp=parseInt(el.getAttribute('data-dp')||'0',10),t0=0,dur=1600;
  function step(t){if(!t0)t0=t;var k=Math.min(1,(t-t0)/dur),q=1-Math.pow(1-k,3);el.textContent=fmt(a+(b-a)*q,dp);if(k<1)requestAnimationFrame(step)}
  setTimeout(function(){requestAnimationFrame(step)},250)})},{threshold:0.6});
 each('.dm-cs .dm-cs-num',function(el){var a=parseFloat(el.getAttribute('data-from')),dp=parseInt(el.getAttribute('data-dp')||'0',10);if(isNaN(a))return;el.textContent=fmt(a,dp);cio.observe(el)})}
/* 2. long page pan follows the scroll (hover pans all the way in CSS) */
var pans=document.querySelectorAll('.dm-cs .dm-cs-pan');
if(pans.length&&!still){var on=false;
 function tick(){on=false;var h=vh();pans.forEach(function(p){var r=p.getBoundingClientRect();if(r.bottom<0||r.top>h)return;var x=(h*0.85-r.top)/(h*0.85+r.height*0.25);x=Math.max(0,Math.min(1,x));p.style.setProperty('--p',x.toFixed(4))})}
 function req(){if(!on){on=true;requestAnimationFrame(tick)}}
 window.addEventListener('scroll',req,{passive:true});window.addEventListener('resize',req);tick()}
/* 3. hero stage leans gently towards the pointer (mouse only) */
if(!still&&window.matchMedia&&matchMedia('(hover: hover) and (pointer: fine)').matches){
 each('.dm-cs .dm-cs-stage',function(st){var sec=st.closest('.et_pb_section')||st;
  sec.addEventListener('pointermove',function(e){var r=st.getBoundingClientRect();st.style.setProperty('--tx',(((e.clientX-r.left)/r.width)-.5).toFixed(3));st.style.setProperty('--ty',(((e.clientY-r.top)/r.height)-.5).toFixed(3))});
  sec.addEventListener('pointerleave',function(){st.style.setProperty('--tx',0);st.style.setProperty('--ty',0)})})}
})})();
/* ---------- v1.1.3 services ---------- */
/* v1.1.3  Services page (.dm-sv): hero "two ways to pay" switch, ownership track, smooth jump links.
   No square brackets. Only runs where .dm-sv is on the page; skips the Divi builder; respects reduced motion. */
(function(){if(window.__dmsv)return;window.__dmsv=1;
function ready(f){document.readyState==='loading'?document.addEventListener('DOMContentLoaded',f):f()}
function inVB(){var d=document.documentElement,b=document.body;if(window.self!==window.top)return true;return d.classList.contains('et-fb')||(b&&(b.classList.contains('et-fb')||b.classList.contains('et-fb-root-ancestor')))||/(^|&|\?)(et_fb|et_pb_preview|et_tb|app_window)=/.test(location.search)}
ready(function(){if(inVB()||window.__dmBuilder||!document.querySelector('.dm-sv'))return;
var still=!!(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches);
var IO=('IntersectionObserver' in window);
function each(sel,f){document.querySelectorAll(sel).forEach(f)}
if(!still)document.documentElement.classList.add('dm-smooth');

/* 1. hero switch: flips between pay monthly and pay upfront; a click takes over from the timer */
each('.dm-sv .dm-svx',function(x){var sw=x.querySelector('.dm-svx-sw'),t=null,user=false;
 function flip(){x.classList.toggle('is-up')}
 function start(){if(still||user||t)return;t=setInterval(flip,4200)}
 function stop(){if(t){clearInterval(t);t=null}}
 if(sw)sw.addEventListener('click',function(){user=true;stop();flip()});
 x.addEventListener('mouseenter',stop);x.addEventListener('mouseleave',start);
 if(IO){new IntersectionObserver(function(es){es.forEach(function(e){e.isIntersecting?start():stop()})},{threshold:0.3}).observe(x)}else start()});

/* 2. ownership track: payments light up as the track scrolls through the screen */
each('.dm-sv .dm-sv-track',function(tr){var li=tr.querySelectorAll('li'),n=li.length,q=0,q2=0;if(!n)return;
 tr.classList.add('dm-sv-js');
 function tick(){var r=tr.getBoundingClientRect(),vh=window.innerHeight||document.documentElement.clientHeight;
  var p=still?1:Math.max(0,Math.min(1,(vh*0.9-r.top)/(vh*0.55)));var k=Math.max(q2,Math.round(p*n));q2=k;
  li.forEach(function(l,i){l.classList.toggle('is-on',i<k);l.style.backgroundPosition=(i/(n-1)*100).toFixed(1)+'% 0'});
  tr.classList.toggle('is-done',k>=n)}
 addEventListener('scroll',function(){if(!q){q=1;requestAnimationFrame(function(){q=0;tick()})}},{passive:true});addEventListener('resize',tick);tick()});
})})();
/* ---------- v1.1.5 Gravity Forms progress meter ---------- */
/* v1.1.5  The v8.3 progress meter (.dm-fp) and field ticks, for Gravity Forms (form.dm-gf) inside a .dm-formcard.
   Listens on the card itself, so it keeps working when GF re-renders the form by AJAX (validation errors), and
   re-scans on gform_post_render / gform/post_render and on any DOM swap. When the confirmation replaces the form,
   the bar fills and the count reads "Sent". No square brackets. Skips the Divi builder. Works with reduced motion
   (the bar transition is already switched off there by the v8.3 CSS). */
(function(){if(window.__dmgf)return;window.__dmgf=1;
function ready(f){document.readyState==='loading'?document.addEventListener('DOMContentLoaded',f):f()}
function inVB(){var d=document.documentElement,b=document.body;if(window.self!==window.top)return true;return d.classList.contains('et-fb')||(b&&(b.classList.contains('et-fb')||b.classList.contains('et-fb-root-ancestor')))||/(^|&|\?)(et_fb|et_pb_preview|et_tb|app_window)=/.test(location.search)}
var SKIP=('gfield--type-honeypot gfield--type-html gfield--type-section gfield--type-page gfield--type-hidden gfield--type-captcha '+
 'gfield--type-turnstile gfield--type-fileupload gfield_visibility_hidden gfield_visibility_administrative gform_hidden gform_validation_container dm-field--privacy').split(' ');
function skip(g){for(var k=0;k<SKIP.length;k++){if(g.classList.contains(SKIP.slice(k,k+1).pop()))return true}return false}
function control(g){var all=g.querySelectorAll('input,textarea,select'),el=null;
 all.forEach(function(x){if(el)return;var t=(x.getAttribute('type')||'').toLowerCase();
  if(t==='hidden'||t==='submit'||t==='button'||t==='checkbox'||t==='radio')return;
  if(x.closest('.gform-phone__dropdown,.gform-phone__search-wrapper,.iti__dropdown-content'))return;el=x});return el}
function filled(el){var v=(el.value||'').trim();if(!v)return false;var t=(el.getAttribute('type')||'').toLowerCase();
 if(t==='email')return /^\S+@\S+\.\S+$/.test(v);
 if(t==='tel')return /\d.*\d.*\d.*\d.*\d/.test(v.replace(/^\+\d{1,4}\s*/,''));  /* a bare "+44" dial code is not an answer */
 return true}
function wire(card){if(card.__dmgf)return card.__dmgf;var fp=card.querySelector('.dm-fp');if(!fp)return null;
 var n=card.querySelector('.dm-fp-n'),bar=card.querySelector('.dm-fp-bar i'),q=0;
 function setText(t){if(n&&n.textContent!==t)n.textContent=t}
 function upd(){q=0;var form=card.querySelector('form.dm-gf');
  if(!form){if(card.querySelector('.gform_confirmation_message,.dm-gf-confirm')){fp.classList.add('is-live','is-sent');if(bar)bar.style.setProperty('--p','1');setText('Sent')}return}
  fp.classList.remove('is-sent');var done=0,total=0,need=0,req=true;
  form.querySelectorAll('.gfield').forEach(function(g){if(skip(g))return;var el=control(g);if(!el)return;total++;var ok=filled(el);if(ok)done++;g.classList.toggle('is-done',ok);
   if(g.classList.contains('gfield_contains_required')||el.getAttribute('aria-required')==='true'||el.required){need++;if(!ok)req=false}});
  if(!total)return;
  fp.classList.add('is-live');if(bar)bar.style.setProperty('--p',Math.max(.04,done/total).toFixed(3));
  setText(done===0?(need+' required, '+(total-need)+' optional'):(done+' of '+total+' answered'));
  form.classList.toggle('is-ready',req)}
 function later(){if(!q){q=1;requestAnimationFrame(upd)}}
 card.addEventListener('input',upd);card.addEventListener('change',upd);card.addEventListener('keyup',later);
 /* GF swaps the whole form (or the confirmation) in by AJAX: rescan when nodes change outside the meter itself */
 if('MutationObserver' in window)new MutationObserver(function(ms){for(var k=0;k<ms.length;k++){var t=ms.slice(k,k+1).pop().target;if(!(t.closest&&t.closest('.dm-fp'))){later();return}}}).observe(card,{childList:true,subtree:true});
 card.__dmgf=upd;upd();return upd}
function scan(){document.querySelectorAll('.dm-formcard').forEach(function(card){if(card.querySelector('form.dm-gf,.dm-gf_wrapper,.gform_confirmation_message'))wire(card)});
 document.querySelectorAll('.dm-formcard').forEach(function(card){if(card.__dmgf)card.__dmgf()})}
ready(function(){if(inVB()||window.__dmBuilder)return;scan();
 if(window.jQuery){window.jQuery(document).on('gform_post_render gform_confirmation_loaded',function(){setTimeout(scan,0)})}
 document.addEventListener('gform/post_render',function(){setTimeout(scan,0)});
 /* autofill sometimes skips input events */
 window.addEventListener('load',function(){setTimeout(scan,600)})})})();
/* Damson 1.2.1: copy the portal pills and the Free health check button into the mobile menu panel */
(function(){function go(){var h=document.querySelector('.dm-hdr');if(!h)return;var nav=h.querySelector('.dm-menu');if(!nav||nav.querySelector('.dm-mx'))return;
var x=document.createElement('div');x.className='dm-mx';
var ps=h.querySelectorAll('.dm-pills a');for(var i=0;i<ps.length;i++){var a=ps[i].cloneNode(true);a.className='dm-mx-pill';x.appendChild(a)}
var c=h.querySelector('.dm-hbtn');if(c){var b=c.cloneNode(true);b.className='dm-mx-cta';x.appendChild(b)}
if(x.children.length)nav.appendChild(x)}
document.readyState==='loading'?document.addEventListener('DOMContentLoaded',go):go()})();
