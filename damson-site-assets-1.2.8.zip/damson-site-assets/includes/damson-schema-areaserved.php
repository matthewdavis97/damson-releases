<?php
/**
 * Damson: service-area schema for Rank Math (included by damson-site-assets 1.2.2+).
 *
 * Rank Math (Local SEO, Business Type = Professional Service) outputs the business node
 * with @id https://damsonwebsitedesign.co.uk/#organization. This filter adds what Rank Math
 * free has no fields for: legalName, email, founder, areaServed, knowsAbout. It removes any
 * "address" or "telephone" from that node (and from Rank Math's #place node, if present),
 * because the business has no public street address or phone. It never adds a telephone.
 * If Rank Math is inactive the filter never fires; if the node is missing, it adds nothing.
 *
 * No output, no remote calls, no database or admin writes. PHP 7.4+.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'damson_schema_area_served' ) ) {
	/**
	 * Filter for rank_math/json_ld.
	 *
	 * @param mixed $data   Rank Math JSON-LD entities, keyed by entity name.
	 * @param mixed $jsonld Rank Math JsonLD instance (unused).
	 * @return mixed
	 */
	function damson_schema_area_served( $data, $jsonld = null ) {
		if ( ! is_array( $data ) ) {
			return $data;
		}
		$org_id   = home_url( '/#organization' );
		$place_id = home_url( '/#place' );
		$extra    = array(
			'legalName'  => 'Worksmarter.digital Ltd',
			'email'      => 'hello@damsonwebsitedesign.co.uk',
			'founder'    => array(
				'@type' => 'Person',
				'name'  => 'Matt Davis',
			),
			'areaServed' => array(
				array( '@type' => 'City', 'name' => 'Gloucester' ),
				array( '@type' => 'City', 'name' => 'Stroud' ),
				array( '@type' => 'City', 'name' => 'Cheltenham' ),
				array( '@type' => 'AdministrativeArea', 'name' => 'Gloucestershire' ),
			),
			'knowsAbout' => array(
				'Web design',
				'WordPress',
				'Search engine optimisation',
				'Local SEO',
				'E-commerce websites',
				'Website hosting',
			),
		);
		foreach ( $data as $key => $node ) {
			if ( ! is_array( $node ) || empty( $node['@id'] ) || ! is_string( $node['@id'] ) ) {
				continue;
			}
			if ( $node['@id'] === $org_id ) {
				foreach ( $extra as $prop => $value ) {
					$data[ $key ][ $prop ] = $value;
				}
				unset( $data[ $key ]['address'], $data[ $key ]['telephone'] );
			} elseif ( $node['@id'] === $place_id ) {
				unset( $data[ $key ]['address'], $data[ $key ]['telephone'] );
			}
		}
		return $data;
	}
}

add_filter( 'rank_math/json_ld', 'damson_schema_area_served', 99, 2 );
