<?php
/**
 * Plugin Name:       Damson Site Assets
 * Description:       Front-end CSS and JS for the Damson Website Design site (Damson v7 to v8.7 blocks). Never loads in wp-admin or the Divi builder.
 * Version:           1.2.8
 * Author:            Damson Website Design
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * License:           GPL-2.0-or-later
 * Text Domain:       damson-site-assets
 */

defined( 'ABSPATH' ) || exit;

define( 'DAMSON_SA_VERSION', '1.2.8' );

// Rank Math JSON-LD filter: legalName, areaServed etc. on the #organization node; strips address/telephone.
require_once __DIR__ . '/includes/damson-schema-areaserved.php';

/**
 * 1.2.8: updates from a public metadata file (Plugin Update Checker 6.0, bundled in lib/).
 * Sites need no token and no wp-config change. Never throws.
 */
function damson_sa_boot_updater() {
	$lib = __DIR__ . '/lib/plugin-update-checker/plugin-update-checker.php';
	if ( ! file_exists( $lib ) ) {
		return;
	}
	try {
		require_once $lib;
		\YahnisElsts\PluginUpdateChecker\v6\PucFactory::buildUpdateChecker(
			'https://matthewdavis97.github.io/damson-releases/damson-site-assets.json',
			__FILE__,
			'damson-site-assets'
		);
	} catch ( \Throwable $e ) {
		return;
	}
}
damson_sa_boot_updater();

/**
 * True when the request is wp-admin or any Divi builder / preview context.
 */
function damson_sa_in_builder() {
	if ( is_admin() ) {
		return true;
	}
	if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
		return true;
	}
	// Query params the Divi 4/5 builder, its app window, previews and the Theme Builder use.
	foreach ( array( 'et_fb', 'et_pb_preview', 'et_tb', 'et_bfb', 'app_window', 'et_block_layout_preview' ) as $param ) {
		if ( isset( $_GET[ $param ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return true;
		}
	}
	return false;
}

/**
 * Asset version: plugin version plus file modification time, so every upload busts caches.
 */
function damson_sa_ver( $file ) {
	$path = plugin_dir_path( __FILE__ ) . $file;
	return DAMSON_SA_VERSION . '.' . ( file_exists( $path ) ? filemtime( $path ) : '0' );
}

/**
 * 1.2.4: which stylesheet to load. The five public templates get a trimmed copy that only holds the rules that page (and the Divi/Gravity Forms
 * state classes it can reach) uses; every other request (404, search, a new page, anything unknown) gets the full damson-site.css as before.
 * Switch the trimmed files off with: add_filter( 'damson_site_assets_trimmed_css', '__return_false' );
 */
function damson_sa_css_rel() {
	$full = 'assets/damson-site.css';
	if ( ! apply_filters( 'damson_site_assets_trimmed_css', true ) ) {
		return $full;
	}
	$tpl = '';
	if ( is_front_page() ) {
		$tpl = 'home';
	} elseif ( is_page( 'services' ) ) {
		$tpl = 'services';
	} elseif ( is_page( 'contact' ) ) {
		$tpl = 'contact';
	} elseif ( is_page( 'free-health-check' ) ) {
		$tpl = 'free-health-check';
	} elseif ( is_page( array( 'terms', 'cookie-policy', 'privacy-policy' ) ) ) {
		$tpl = 'legal';
	}
	if ( '' === $tpl ) {
		return $full;
	}
	$rel = 'assets/damson-site.' . $tpl . '.css';
	return file_exists( plugin_dir_path( __FILE__ ) . $rel ) ? $rel : $full;
}

function damson_sa_enqueue() {
	if ( damson_sa_in_builder() || apply_filters( 'damson_site_assets_disable', false ) ) {
		return;
	}
	$css = damson_sa_css_rel();
	wp_enqueue_style( 'damson-site', plugins_url( $css, __FILE__ ), array(), damson_sa_ver( $css ) );
	wp_enqueue_script( 'damson-site', plugins_url( 'assets/damson-site.js', __FILE__ ), array(), damson_sa_ver( 'assets/damson-site.js' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
}
/**
 * 1.2.6: body class "dm-pg-support" on the Support page (slug support), so its full-width fallback CSS does not depend on a page ID.
 */
function damson_sa_body_class( $classes ) {
	if ( is_page( 'support' ) ) {
		$classes[] = 'dm-pg-support';
	}
	return $classes;
}
add_filter( 'body_class', 'damson_sa_body_class' );

// Late priority so the stylesheet prints after the theme's own styles.
add_action( 'wp_enqueue_scripts', 'damson_sa_enqueue', 999 );
