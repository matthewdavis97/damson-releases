=== Damson Site Assets ===
Contributors: damsonwebsitedesign
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.2.8
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Front-end stylesheet and script for damsonwebsitedesign.co.uk.

* assets/damson-site.css  - Damson v7, v8, v8.1, v8.2 (as live) and v8.3, v8.5 (builder-safe revision) CSS, plus case study pages (.dm-cs) the Services page (.dm-sv) and the Gravity Forms Contact / Free Health Check forms (.dm-gf).
* assets/damson-site.js   - builder guard + helpers, v8 motion, v8.1 bento, v8.3 forms, v8.5 health check, case study motion (.dm-cs), Services page motion (.dm-sv), Gravity Forms progress meter (.dm-gf).

Loads on the front end only. It never loads in wp-admin, the Divi Visual Builder (et_core_is_fb_enabled(),
?et_fb=…), Divi previews or the Theme Builder. The script also skips itself inside any iframe and when it
sees Divi builder classes. Animations respect prefers-reduced-motion.

Updates show on the Plugins screen like a normal plugin. You can also upload a new zip (Replace current with uploaded). The ?ver= query string changes automatically with the file time.

Emergency off switch: deactivate the plugin, or add_filter( 'damson_site_assets_disable', '__return_true' );

Changelog

= 1.2.8 =
* Updates no longer need a GitHub token or a wp-config.php change. The plugin checks a public metadata file and shows "Update available" on the Plugins screen. No CSS or JS changes.

= 1.2.3 =
* 1.2.3 - Services ownership track shown as one continuous gradient bar instead of 24 blocks (CSS only). All 1.2.2 code unchanged.
* 1.2.2 - Schema: includes/damson-schema-areaserved.php adds a rank_math/json_ld filter (priority 99) that adds legalName, email, founder, areaServed (Gloucester, Stroud, Cheltenham, Gloucestershire) and knowsAbout to Rank Math's #organization node and removes any address or telephone from it and from the #place node. Does nothing if Rank Math is inactive or the node is missing. All 1.2.1 CSS and JS unchanged.
* 1.2.1 - Mobile fixes. Services index rows no longer collapse and overlap on tablets and phones; How it works is a single vertical timeline on tablets; portal pills stay visible from 901px to 1080px; the open mobile menu now includes the Hosting Portal and Client Portal pills and the Free health check button (copied in by the script, all pages). No has() selectors. All 1.2.0 CSS and JS unchanged.
* 1.2.0 - Services page: 30px space above the care plans button; at 1100px and wider the page is a touch more compact (section padding 120/100px to 88px, hero 170/90 to 150/80, h1/h2 about 12% smaller, tighter plan and SEO cards, list rows and services index rows, gentler one-off build staircase). Scoped to .dm-sv; bottom Get in touch band unchanged. No has() selectors. All 1.1.9 CSS and JS unchanged.
* 1.1.9 - Services page "Get in touch" band (.dm-sv-end): bigger (104/72/56px padding, larger heading); the button and "Not sure yet?" line form one stack centred on each other and vertically centred against the heading on desktop, left-aligned stack on tablet and phone. No has() selectors. All 1.1.8 CSS and JS unchanged.
* 1.1.8 - Services page v8.10: SEO glass cards get a full-width "Request a quote" button pinned to the card bottom (equal-height cards on desktop); the closing call to action becomes a compact full-width band (.dm-sv-end.dm-band) with a smaller heading. No has() selectors. All 1.1.7 CSS (including the legal page styles) and JS unchanged.
* 1.1.7 - Legal pages (Privacy policy, Cookie policy, Website terms): calm long-form layout scoped to .dm-lg-hero and .dm-lg. Smaller hero title, 760px reading column, "On this page" jump list (two columns on desktop), 1.45-1.85rem section headings with scroll offset for the fixed header, list, link and inline code styles, and bordered tables that scroll sideways on phones. No has() selectors. All 1.1.6 CSS and JS unchanged.
* 1.1.6 - Compact Gravity Forms: the Contact / Free Health Check forms (.dm-gf) take noticeably less height with the same look. About 40% smaller gaps between fields (18px to 11px), 46px inputs (were 52px, still 16px text so iOS does not zoom), 4px label spacing, a 96px message box, tighter privacy note, footer, button, error and confirmation spacing. GF Orbital variables (--gf-ctrl-size, --gf-form-gap-y, --gf-field-gap-*, --gf-label-space-primary, --gf-ctrl-textarea-height, --gf-form-footer-margin-y-start) set to match. Form card (.dm-formcard) padding trimmed (44px to 36-38px; 28/20px to 24/18px on mobile). Half-width pairs still stack under 640px. No has() selectors. All 1.1.5 CSS and JS unchanged.
* 1.1.5 - Progress meter and field ticks for the Gravity Forms Contact / Free Health Check forms: the .dm-fp meter in a .dm-formcard now follows the required and optional GF fields (form.dm-gf), survives AJAX re-renders (gform_post_render, gform/post_render, DOM swaps) and shows a full bar with "Sent" when the confirmation replaces the form. Green ticks on answered GF labels, ready glow on the submit button. The shortcode Text module uses class dm-gf-host (not dm-form). No has() selectors; reduced motion respected. All 1.1.4 CSS and JS unchanged.
* 1.1.4 - Gravity Forms styling for the Contact and Free Health Check forms (form CSS class dm-gf, dm-gf--contact / dm-gf--hc; wrapper dm-gf_wrapper): same fields, labels, pink focus ring and gradient pill button as the Divi contact form; two-up half-width fields that stack under 640px; styled dropdown, international phone field, privacy note, error states and a success panel for the confirmation (.dm-gf-confirm). Works with the Orbital and legacy gravity-theme form themes. No has() selectors; reduced motion respected. JS and all 1.1.3 CSS unchanged.
* 1.1.3 - Services page (section class dm-sv, page 361): hero "two ways to pay" switch, numbered services index, pay-monthly plans with a 24-payment ownership track, care plan comparison table, SEO glass cards, one-off build staircase, recent-work stage, 4-step timeline. Styles and script only apply where .dm-sv is on the page; no has() selectors; reduced motion respected. Adds a page-id-361 full-width fallback. Everything from 1.1.2 is unchanged.
* 1.1.2 - Case study pages (section class dm-cs): tilted browser/phone hero mockups, floating stat chips, screenshot before/after slider, long-page pan, browser/phone-framed gallery images, count-up results cards. CSS and JS only run where .dm-cs is on the page; reduced motion respected.
* 1.1.1 - Removes the 1px white line above the header (empty Theme Builder header wrapper kept Divi's 1px column min-height).
* 1.1.0 - v8.5 Free health check: sample report visuals match the real report (overall score, six areas, top 5 fixes). v8.4 radar / gauge / PDF styles removed.
* 1.0.0 - first release (v7 to v8.4).

= 1.2.4 =
* Per-template stylesheets: the Home, Services, Contact, Free Health Check and legal pages (Terms, Cookie policy, Privacy policy) load assets/damson-site.<template>.css, a copy of damson-site.css with the rules that template cannot use removed (checked on 9 Nov 2026 across 360-1920 px, with the menu, toggles and scroll states open; Divi, Gravity Forms and JS-toggled state classes are always kept). Every other request (404, search, new pages, case-study pages) still gets the full damson-site.css.
* Turn it off without a re-upload: add_filter( 'damson_site_assets_trimmed_css', '__return_false' ); in a Code Snippet.

= 1.2.7 =
* Updates from GitHub: the plugin checks matthewdavis97/damson-site-assets for new releases (Plugin Update Checker 6.0, bundled in lib/) and shows "Update available" on the Plugins screen. Private repo: add define( 'DAMSON_UPDATES_TOKEN', '...' ); to wp-config.php. Without the token it quietly finds nothing. No CSS or JS changes.

= 1.2.6 =
* Support page (/support/, section class dm-sp): compact plum hero with a "Site down? Call" card, the support request form in the Contact page form card (Gravity Forms class dm-gf dm-gf--support), two columns of Common questions toggles, portal band. Gravity Forms multi-file upload styled to match the other fields (drop area, file list, rules line) for any .dm-gf form. Body class dm-pg-support (added by PHP when is_page( 'support' )) gives the page the same full-width, no-title fallback as the other pages. The form progress meter ignores file-upload fields. Appended to damson-site.css only; the trimmed per-template stylesheets are unchanged. No has() selectors.

= 1.2.5 =
* Master logo (22 Nov 2026): the header and footer .dm-logo now draw the master horizontal lockup taken from the business card. That's the petal icon with a 120deg #ff6347 / #f92c8b / #b02cd6 gradient, "Damson" in Outfit 700 at -0.03em and "WEBSITE DESIGN" in Poppins 500 at +0.20em in #a99ea9. It's an inline SVG data URI at 43px tall, with the link text kept and visually hidden. Header padding goes to 20px / 20.40625px (10px / 10.40625px when solid), so the header height doesn't change (83.406px, 63.406px solid). CSS only, appended to every stylesheet. No :has().
