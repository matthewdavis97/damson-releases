<?php
/**
 * Admin-side Damson branding: footer credit, dashboard widget, admin bar link.
 * Nothing here touches the public front end. No external requests, no tracking.
 *
 * @package Damson_Website_Design
 */

defined( 'ABSPATH' ) || exit;

/**
 * Admin footer: "Website managed by Damson Website Design".
 *
 * @return string
 */
function dwd_admin_footer_text() {
	return sprintf(
		/* translators: 1: Damson Website Design link, 2: Client Portal link. */
		esc_html__( 'Website managed by %1$s. Need help? Visit the %2$s.', 'damson-website-design' ),
		sprintf(
			'<a href="%s" target="_blank" rel="noopener">%s</a>',
			esc_url( DWD_URL_WEBSITE ),
			esc_html__( 'Damson Website Design', 'damson-website-design' )
		),
		sprintf(
			'<a href="%s" target="_blank" rel="noopener">%s</a>',
			esc_url( DWD_URL_CLIENT_PORTAL ),
			esc_html__( 'Client Portal', 'damson-website-design' )
		)
	);
}
add_filter( 'admin_footer_text', 'dwd_admin_footer_text' );

/**
 * Support links shown in the dashboard widget and admin bar.
 *
 * @return array[] Each item: url, label, desc.
 */
function dwd_support_links() {
	$links = array(
		array(
			'url'   => DWD_URL_CLIENT_PORTAL,
			'label' => __( 'Client Portal', 'damson-website-design' ),
			'desc'  => __( 'Get help with your website or ask for changes.', 'damson-website-design' ),
		),
		array(
			'url'   => DWD_URL_HOSTING_PORTAL,
			'label' => __( 'Hosting Portal', 'damson-website-design' ),
			'desc'  => __( 'Log in to your hosting account.', 'damson-website-design' ),
		),
		array(
			'url'   => DWD_URL_WEBSITE,
			'label' => __( 'damsonwebsitedesign.co.uk', 'damson-website-design' ),
			'desc'  => __( 'Website design, SEO and ongoing care.', 'damson-website-design' ),
		),
	);

	/**
	 * Filter the Damson support links.
	 *
	 * @param array[] $links Support links.
	 */
	return apply_filters( 'dwd_support_links', $links );
}

/**
 * Register the dashboard widget.
 */
function dwd_register_dashboard_widget() {
	if ( ! current_user_can( 'edit_posts' ) ) {
		return;
	}
	wp_add_dashboard_widget(
		'dwd_dashboard_widget',
		esc_html__( 'Damson Website Design', 'damson-website-design' ),
		'dwd_render_dashboard_widget'
	);

	// Move it to the top of the first column.
	global $wp_meta_boxes;
	if ( isset( $wp_meta_boxes['dashboard']['normal']['core']['dwd_dashboard_widget'] ) ) {
		$widget = array( 'dwd_dashboard_widget' => $wp_meta_boxes['dashboard']['normal']['core']['dwd_dashboard_widget'] );
		unset( $wp_meta_boxes['dashboard']['normal']['core']['dwd_dashboard_widget'] );
		$wp_meta_boxes['dashboard']['normal']['core'] = array_merge( $widget, $wp_meta_boxes['dashboard']['normal']['core'] ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
	}
}
add_action( 'wp_dashboard_setup', 'dwd_register_dashboard_widget' );

/**
 * Dashboard widget output.
 */
function dwd_render_dashboard_widget() {
	?>
	<div class="dwd-widget">
		<div class="dwd-widget__brand">
			<img
				class="dwd-widget__logo"
				src="<?php echo esc_url( DWD_THEME_URI . '/assets/img/damson-horizontal-reverse.svg' ); ?>"
				width="180"
				height="48"
				alt=""
				aria-hidden="true"
			/>
			<span class="dwd-widget__badge"><?php esc_html_e( 'Managed website', 'damson-website-design' ); ?></span>
		</div>
		<p class="dwd-widget__intro">
			<?php esc_html_e( 'This website is designed, built and looked after by Damson Website Design. If something is not working, or you would like a change, get in touch and we will sort it.', 'damson-website-design' ); ?>
		</p>
		<ul class="dwd-widget__links">
			<?php foreach ( dwd_support_links() as $link ) : ?>
				<li>
					<a href="<?php echo esc_url( $link['url'] ); ?>" target="_blank" rel="noopener">
						<strong><?php echo esc_html( $link['label'] ); ?></strong>
						<span class="screen-reader-text"><?php esc_html_e( '(opens in a new tab)', 'damson-website-design' ); ?></span>
					</a>
					<span class="dwd-widget__desc"><?php echo esc_html( $link['desc'] ); ?></span>
				</li>
			<?php endforeach; ?>
		</ul>
		<div class="dwd-widget__tips">
			<h3><?php esc_html_e( 'Quick tips', 'damson-website-design' ); ?></h3>
			<ul>
				<li><?php esc_html_e( 'To edit a page, open it under Pages and click "Edit With The Divi Builder".', 'damson-website-design' ); ?></li>
				<li><?php esc_html_e( 'Please check with us before updating the theme, installing plugins or changing settings you are not sure about.', 'damson-website-design' ); ?></li>
				<li><?php esc_html_e( 'When reporting a problem, include the page address and a screenshot. It helps us fix it faster.', 'damson-website-design' ); ?></li>
			</ul>
		</div>
		<p class="dwd-widget__cta">
			<a class="button button-primary" href="<?php echo esc_url( DWD_URL_SUPPORT ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Get support', 'damson-website-design' ); ?></a>
		</p>
	</div>
	<?php
}

/**
 * Widget styles, on the dashboard only.
 *
 * @param string $hook_suffix Current admin page.
 */
function dwd_admin_styles( $hook_suffix ) {
	if ( 'index.php' !== $hook_suffix ) {
		return;
	}
	$file = DWD_THEME_DIR . '/assets/css/admin.css';
	wp_enqueue_style(
		'dwd-admin',
		DWD_THEME_URI . '/assets/css/admin.css',
		array(),
		file_exists( $file ) ? (string) filemtime( $file ) : DWD_THEME_VERSION
	);
}
add_action( 'admin_enqueue_scripts', 'dwd_admin_styles' );

/**
 * Small "Damson support" item in the admin bar (logged-in editors only).
 * Turn off per site in Appearance > Damson Settings (or with the dwd_show_admin_bar_node filter).
 *
 * @param WP_Admin_Bar $wp_admin_bar Admin bar.
 */
function dwd_admin_bar_node( $wp_admin_bar ) {
	if ( ! current_user_can( 'edit_posts' ) || ! apply_filters( 'dwd_show_admin_bar_node', empty( dwd_get_settings()['hide_admin_bar_node'] ) ) ) {
		return;
	}
	$wp_admin_bar->add_node(
		array(
			'id'     => 'dwd-support',
			'parent' => 'top-secondary',
			'title'  => esc_html__( 'Damson support', 'damson-website-design' ),
			'href'   => esc_url( DWD_URL_CLIENT_PORTAL ),
			'meta'   => array(
				'target' => '_blank',
				'rel'    => 'noopener',
				'title'  => esc_attr__( 'Website managed by Damson Website Design', 'damson-website-design' ),
			),
		)
	);
	foreach ( dwd_support_links() as $i => $link ) {
		$wp_admin_bar->add_node(
			array(
				'id'     => 'dwd-support-' . absint( $i ),
				'parent' => 'dwd-support',
				'title'  => esc_html( $link['label'] ),
				'href'   => esc_url( $link['url'] ),
				'meta'   => array(
					'target' => '_blank',
					'rel'    => 'noopener',
				),
			)
		);
	}
}
add_action( 'admin_bar_menu', 'dwd_admin_bar_node', 100 );
