<?php
/**
 * Stylesheets.
 *
 * Divi 4.10+ enqueues its own CSS and also loads the active child theme's
 * style.css (handle "divi-style", with the parent as "divi-style-parent").
 * Older Divi versions load only the parent stylesheet. This handles both:
 * it never loads style.css twice and always versions it by file time so
 * browsers pick up edits straight away.
 *
 * @package Damson_Website_Design
 */

defined( 'ABSPATH' ) || exit;

/**
 * Path part of a URL, for comparing stylesheet sources.
 *
 * @param string $url URL.
 * @return string
 */
function dwd_url_path( $url ) {
	$path = wp_parse_url( (string) $url, PHP_URL_PATH );
	return $path ? untrailingslashit( $path ) : '';
}

/**
 * Enqueue the child stylesheet after Divi.
 */
function dwd_enqueue_styles() {
	$child_file = DWD_THEME_DIR . '/style.css';
	$child_ver  = file_exists( $child_file ) ? (string) filemtime( $child_file ) : DWD_THEME_VERSION;
	$child_path = dwd_url_path( get_stylesheet_uri() );
	$styles     = wp_styles();

	// 1. Divi already loads our style.css: just give it a cache-busting version.
	foreach ( $styles->registered as $handle => $style ) {
		if ( is_string( $style->src ) && '' !== $style->src && dwd_url_path( $style->src ) === $child_path ) {
			$style->ver = $child_ver;
			if ( ! wp_style_is( $handle, 'enqueued' ) ) {
				wp_enqueue_style( $handle );
			}
			dwd_enqueue_settings_css( $handle );
			return;
		}
	}

	// 2. Work out the parent handle Divi used.
	$parent_handle = 'divi-style';
	if ( wp_style_is( 'divi-style-parent', 'registered' ) ) {
		$parent_handle = 'divi-style-parent';
	}

	// 3. Parent not loaded at all (unusual): load Divi's style.css ourselves.
	if ( ! wp_style_is( $parent_handle, 'registered' ) ) {
		$parent = wp_get_theme( get_template() );
		wp_enqueue_style(
			$parent_handle,
			get_template_directory_uri() . '/style.css',
			array(),
			$parent->get( 'Version' )
		);
	}

	// 4. Child stylesheet, after the parent.
	wp_enqueue_style(
		'damson-website-design',
		get_stylesheet_uri(),
		array( $parent_handle ),
		$child_ver
	);
	dwd_enqueue_settings_css( 'damson-website-design' );
}
add_action( 'wp_enqueue_scripts', 'dwd_enqueue_styles', 20 );
