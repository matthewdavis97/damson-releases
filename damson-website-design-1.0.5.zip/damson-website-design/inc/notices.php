<?php
/**
 * Admin notice: suggest the Damson Login plugin if it is not active.
 * Shown only to administrators (manage_options). Dismissed per user.
 * The plugin is not bundled with this theme.
 *
 * @package Damson_Website_Design
 */

defined( 'ABSPATH' ) || exit;

define( 'DWD_LOGIN_PLUGIN', 'damson-login/damson-login.php' );
define( 'DWD_NOTICE_META', 'dwd_dismissed_login_notice' );

/**
 * Whether Damson Login is active.
 *
 * @return bool
 */
function dwd_login_plugin_active() {
	if ( defined( 'DAMSON_LOGIN_VERSION' ) ) {
		return true;
	}
	if ( ! function_exists( 'is_plugin_active' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	return is_plugin_active( DWD_LOGIN_PLUGIN );
}

/**
 * Show the notice.
 */
function dwd_login_plugin_notice() {
	if ( ! current_user_can( 'manage_options' ) || dwd_login_plugin_active() ) {
		return;
	}
	if ( get_user_meta( get_current_user_id(), DWD_NOTICE_META, true ) ) {
		return;
	}

	$installed = file_exists( WP_PLUGIN_DIR . '/' . DWD_LOGIN_PLUGIN );
	$dismiss   = wp_nonce_url( add_query_arg( 'dwd-dismiss-login-notice', '1' ), 'dwd_dismiss_login_notice' );
	?>
	<div class="notice notice-info is-dismissible dwd-login-notice" data-dismiss-url="<?php echo esc_url( $dismiss ); ?>">
		<p>
			<strong><?php esc_html_e( 'Damson Website Design:', 'damson-website-design' ); ?></strong>
			<?php
			if ( $installed ) {
				esc_html_e( 'The Damson Login plugin is installed but not active. Activate it to give this site the Damson-managed login screen.', 'damson-website-design' );
			} else {
				esc_html_e( 'Add the Damson Login plugin to give this site the Damson-managed login screen.', 'damson-website-design' );
			}
			?>
		</p>
		<p>
			<?php if ( $installed && current_user_can( 'activate_plugins' ) ) : ?>
				<a class="button button-primary" href="<?php echo esc_url( admin_url( 'plugins.php?plugin_status=inactive' ) ); ?>"><?php esc_html_e( 'Go to Plugins', 'damson-website-design' ); ?></a>
			<?php elseif ( current_user_can( 'install_plugins' ) ) : ?>
				<a class="button button-primary" href="<?php echo esc_url( admin_url( 'plugin-install.php?tab=upload' ) ); ?>"><?php esc_html_e( 'Upload plugin', 'damson-website-design' ); ?></a>
			<?php endif; ?>
			<a class="button-link" href="<?php echo esc_url( $dismiss ); ?>"><?php esc_html_e( 'Don\'t show again', 'damson-website-design' ); ?></a>
		</p>
	</div>
	<?php
}
add_action( 'admin_notices', 'dwd_login_plugin_notice' );

/**
 * Save the dismissal (link click, or the X button via the small script below).
 */
function dwd_handle_notice_dismiss() {
	if ( empty( $_GET['dwd-dismiss-login-notice'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return;
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	check_admin_referer( 'dwd_dismiss_login_notice' );
	update_user_meta( get_current_user_id(), DWD_NOTICE_META, 1 );

	if ( wp_doing_ajax() || ! empty( $_GET['dwd-ajax'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		wp_die( '', '', array( 'response' => 204 ) );
	}
	wp_safe_redirect( remove_query_arg( array( 'dwd-dismiss-login-notice', '_wpnonce' ) ) );
	exit;
}
add_action( 'admin_init', 'dwd_handle_notice_dismiss' );

/**
 * Make the notice's X button remember the choice.
 */
function dwd_notice_script() {
	if ( ! current_user_can( 'manage_options' ) || dwd_login_plugin_active() ) {
		return;
	}
	$js = "document.addEventListener('click',function(e){var b=e.target.closest('.dwd-login-notice .notice-dismiss');if(!b){return;}var n=b.closest('.dwd-login-notice');var u=n&&n.getAttribute('data-dismiss-url');if(u){fetch(u+'&dwd-ajax=1',{credentials:'same-origin'});}});";
	wp_add_inline_script( 'common', $js );
}
add_action( 'admin_enqueue_scripts', 'dwd_notice_script' );
