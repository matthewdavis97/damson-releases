<?php
/**
 * Per-site settings: stored in the database, so theme updates never touch them.
 *
 * Appearance > Damson Settings saves one option (dwd_settings). The values print
 * as a :root { --dwd-...: ... } block after the child stylesheet, so they
 * override the neutral defaults in style.css. A field left empty (or set back to
 * the default) uses whatever style.css ships with.
 *
 * @package Damson_Website_Design
 */

defined( 'ABSPATH' ) || exit;

define( 'DWD_SETTINGS_OPTION', 'dwd_settings' );
define( 'DWD_SETTINGS_PAGE', 'damson-settings' );

/**
 * Editable CSS variables. Keep the defaults in step with the :root block in style.css.
 *
 * type: color (hex), number (unitless), length (px, rem, em, ch or 0).
 *
 * @return array[]
 */
function dwd_settings_fields() {
	return array(
		'primary'          => array( 'color', '#1f2937', __( 'Primary', 'damson-website-design' ), __( 'Links, focus rings, highlights.', 'damson-website-design' ), 'colours' ),
		'primary-hover'    => array( 'color', '#111827', __( 'Primary (hover)', 'damson-website-design' ), __( 'A darker shade of primary for hover states.', 'damson-website-design' ), 'colours' ),
		'accent'           => array( 'color', '#2563eb', __( 'Accent', 'damson-website-design' ), __( 'Buttons, badges, small details.', 'damson-website-design' ), 'colours' ),
		'accent-contrast'  => array( 'color', '#ffffff', __( 'Text on accent', 'damson-website-design' ), __( 'Text colour that sits on top of the accent colour.', 'damson-website-design' ), 'colours' ),
		'text'             => array( 'color', '#1f2933', __( 'Body text', 'damson-website-design' ), '', 'colours' ),
		'text-muted'       => array( 'color', '#5b6672', __( 'Muted text', 'damson-website-design' ), __( 'Captions, meta, small print.', 'damson-website-design' ), 'colours' ),
		'heading'          => array( 'color', '#111827', __( 'Headings', 'damson-website-design' ), '', 'colours' ),
		'surface'          => array( 'color', '#ffffff', __( 'Page background', 'damson-website-design' ), '', 'colours' ),
		'surface-alt'      => array( 'color', '#f5f6f8', __( 'Alternate background', 'damson-website-design' ), __( 'Used by the dwd-surface-alt helper class.', 'damson-website-design' ), 'colours' ),
		'border'           => array( 'color', '#e3e6ea', __( 'Lines and borders', 'damson-website-design' ), '', 'colours' ),
		'header-offset'    => array( 'length', '90px', __( 'Header height', 'damson-website-design' ), __( 'Height of a fixed header, so anchor links do not hide under it. Use 0px if the header is not fixed.', 'damson-website-design' ), 'layout' ),
		'radius'           => array( 'length', '8px', __( 'Corner radius', 'damson-website-design' ), __( 'Cards and focus rings.', 'damson-website-design' ), 'layout' ),
		'measure'          => array( 'length', '68ch', __( 'Line length', 'damson-website-design' ), __( 'Comfortable maximum line length (dwd-measure).', 'damson-website-design' ), 'layout' ),
		'line-height'      => array( 'number', '1.7', __( 'Body line height', 'damson-website-design' ), '', 'layout' ),
		'heading-line'     => array( 'number', '1.2', __( 'Heading line height', 'damson-website-design' ), '', 'layout' ),
		'space-xs'         => array( 'length', '0.5rem', __( 'Space: extra small', 'damson-website-design' ), '', 'spacing' ),
		'space-sm'         => array( 'length', '1rem', __( 'Space: small', 'damson-website-design' ), '', 'spacing' ),
		'space-md'         => array( 'length', '2rem', __( 'Space: medium', 'damson-website-design' ), '', 'spacing' ),
		'space-lg'         => array( 'length', '4rem', __( 'Space: large', 'damson-website-design' ), '', 'spacing' ),
		'space-xl'         => array( 'length', '6rem', __( 'Space: extra large', 'damson-website-design' ), '', 'spacing' ),
	);
}

/**
 * Validate one value. Returns the clean value, or '' when it is invalid.
 *
 * @param string $key   Field key.
 * @param mixed  $value Raw value.
 * @return string
 */
function dwd_clean_value( $key, $value ) {
	$fields = dwd_settings_fields();
	if ( ! isset( $fields[ $key ] ) || ! is_scalar( $value ) ) {
		return '';
	}
	$value = strtolower( trim( (string) $value ) );
	switch ( $fields[ $key ][0] ) {
		case 'color':
			$clean = sanitize_hex_color( $value );
			return $clean ? $clean : '';
		case 'number':
			return preg_match( '/^\d{1,2}(\.\d{1,3})?$/', $value ) && (float) $value >= 0.5 && (float) $value <= 4 ? $value : '';
		case 'length':
			return preg_match( '/^(0|\d{1,3}(\.\d{1,3})?(px|rem|em|ch))$/', $value ) ? $value : '';
	}
	return '';
}

/**
 * Saved settings (an array; empty when nothing has been set).
 *
 * @return array
 */
function dwd_get_settings() {
	$saved = get_option( DWD_SETTINGS_OPTION, array() );
	return is_array( $saved ) ? $saved : array();
}

/**
 * Add a settings notice once (the sanitise callback can run twice on the first save).
 *
 * @param string $code    Notice code.
 * @param string $message Message.
 * @param string $type    error or updated.
 */
function dwd_settings_notice( $code, $message, $type = 'error' ) {
	foreach ( get_settings_errors( DWD_SETTINGS_OPTION ) as $existing ) {
		if ( $existing['code'] === $code ) {
			return;
		}
	}
	add_settings_error( DWD_SETTINGS_OPTION, $code, $message, $type );
}

/**
 * Sanitise the whole option before it is saved.
 *
 * @param mixed $input Posted values.
 * @return array
 */
function dwd_sanitize_settings( $input ) {
	$old = dwd_get_settings();
	if ( ! current_user_can( 'manage_options' ) || ! is_array( $input ) ) {
		return $old;
	}
	$fields = dwd_settings_fields();
	$out    = array();

	foreach ( $fields as $key => $field ) {
		$raw = isset( $input[ $key ] ) ? trim( (string) $input[ $key ] ) : '';
		if ( '' === $raw ) {
			continue;
		}
		$clean = dwd_clean_value( $key, $raw );
		if ( '' === $clean ) {
			dwd_settings_notice(
				'dwd_bad_' . $key,
				sprintf(
					/* translators: %s: setting name */
					__( '"%s" was not a valid value, so the previous value was kept.', 'damson-website-design' ),
					$field[2]
				)
			);
			if ( isset( $old[ $key ] ) ) {
				$out[ $key ] = $old[ $key ];
			}
			continue;
		}
		// Same as the shipped default: store nothing, so future default changes still apply.
		if ( $clean !== $field[1] ) {
			$out[ $key ] = $clean;
		}
	}

	if ( isset( $input['custom_css'] ) ) {
		$css = trim( wp_strip_all_tags( (string) $input['custom_css'] ) );
		if ( strlen( $css ) > 50000 ) {
			$css = substr( $css, 0, 50000 );
		}
		if ( '' !== $css ) {
			$out['custom_css'] = $css;
		}
	}

	if ( ! empty( $input['hide_admin_bar_node'] ) ) {
		$out['hide_admin_bar_node'] = '1';
	}

	dwd_settings_notice( 'dwd_saved', __( 'Settings saved.', 'damson-website-design' ), 'updated' );

	return $out;
}

/**
 * Register the option with the Settings API (this also gives us the nonce and capability check).
 */
function dwd_register_settings() {
	register_setting(
		'dwd_settings_group',
		DWD_SETTINGS_OPTION,
		array(
			'type'              => 'array',
			'sanitize_callback' => 'dwd_sanitize_settings',
			'default'           => array(),
			'show_in_rest'      => false,
		)
	);
}
add_action( 'admin_init', 'dwd_register_settings' );

/**
 * Only administrators may save the settings.
 *
 * @return string
 */
function dwd_settings_capability() {
	return 'manage_options';
}
add_filter( 'option_page_capability_dwd_settings_group', 'dwd_settings_capability' );

/**
 * Add the page under Appearance.
 */
function dwd_settings_menu() {
	add_theme_page(
		__( 'Damson Settings', 'damson-website-design' ),
		__( 'Damson Settings', 'damson-website-design' ),
		'manage_options',
		DWD_SETTINGS_PAGE,
		'dwd_render_settings_page'
	);
}
add_action( 'admin_menu', 'dwd_settings_menu' );

/**
 * Colour picker assets, on our page only.
 *
 * @param string $hook Admin page hook.
 */
function dwd_settings_assets( $hook ) {
	if ( 'appearance_page_' . DWD_SETTINGS_PAGE !== $hook ) {
		return;
	}
	wp_enqueue_style( 'wp-color-picker' );
	wp_enqueue_script( 'wp-color-picker' );
	wp_add_inline_script( 'wp-color-picker', 'jQuery(function($){$(".dwd-color").wpColorPicker();});' );
	wp_add_inline_style(
		'wp-color-picker',
		'.dwd-settings .form-table th{width:220px}.dwd-settings .description{max-width:520px}.dwd-settings textarea{width:100%;max-width:720px;font-family:monospace}.dwd-settings .dwd-default{color:#646970;margin-left:6px}'
	);
}
add_action( 'admin_enqueue_scripts', 'dwd_settings_assets' );

/**
 * Print one group of fields.
 *
 * @param string $group Group key.
 * @param array  $saved Saved settings.
 */
function dwd_render_fields( $group, $saved ) {
	echo '<table class="form-table" role="presentation"><tbody>';
	foreach ( dwd_settings_fields() as $key => $field ) {
		if ( $field[4] !== $group ) {
			continue;
		}
		$id    = 'dwd-' . $key;
		$value = isset( $saved[ $key ] ) ? $saved[ $key ] : '';
		echo '<tr><th scope="row"><label for="' . esc_attr( $id ) . '">' . esc_html( $field[2] ) . '</label></th><td>';
		printf(
			'<input type="text" id="%1$s" name="%2$s[%3$s]" value="%4$s" class="%5$s" data-default-color="%6$s" placeholder="%6$s" maxlength="12" />',
			esc_attr( $id ),
			esc_attr( DWD_SETTINGS_OPTION ),
			esc_attr( $key ),
			esc_attr( $value ),
			'color' === $field[0] ? 'dwd-color' : 'small-text',
			esc_attr( $field[1] )
		);
		if ( 'color' !== $field[0] ) {
			echo '<span class="dwd-default">' . esc_html( sprintf( /* translators: %s: default value */ __( 'Default: %s', 'damson-website-design' ), $field[1] ) ) . '</span>';
		}
		if ( '' !== $field[3] ) {
			echo '<p class="description">' . esc_html( $field[3] ) . '</p>';
		}
		echo '</td></tr>';
	}
	echo '</tbody></table>';
}

/**
 * The settings page.
 */
function dwd_render_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to change these settings.', 'damson-website-design' ) );
	}
	$saved = dwd_get_settings();
	?>
	<div class="wrap dwd-settings">
		<h1><?php esc_html_e( 'Damson Settings', 'damson-website-design' ); ?></h1>
		<p><?php esc_html_e( 'These settings are saved in the database, so updating the theme never changes them. Leave a field empty to use the theme default. Tip: match Primary and Accent to the colours in Divi > Theme Options so the builder and the front end agree.', 'damson-website-design' ); ?></p>
		<?php settings_errors( DWD_SETTINGS_OPTION ); ?>
		<form method="post" action="options.php">
			<?php settings_fields( 'dwd_settings_group' ); ?>

			<h2><?php esc_html_e( 'Colours', 'damson-website-design' ); ?></h2>
			<?php dwd_render_fields( 'colours', $saved ); ?>

			<h2><?php esc_html_e( 'Layout and type', 'damson-website-design' ); ?></h2>
			<?php dwd_render_fields( 'layout', $saved ); ?>

			<h2><?php esc_html_e( 'Spacing scale', 'damson-website-design' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Used by the helper classes (dwd-pad-*, dwd-mb-*, dwd-card). Lengths in px, rem, em or ch.', 'damson-website-design' ); ?></p>
			<?php dwd_render_fields( 'spacing', $saved ); ?>

			<h2><?php esc_html_e( 'Custom CSS', 'damson-website-design' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Site-specific styles. Printed after the theme stylesheet.', 'damson-website-design' ); ?></p>
			<textarea name="<?php echo esc_attr( DWD_SETTINGS_OPTION ); ?>[custom_css]" rows="10" spellcheck="false"><?php echo esc_textarea( isset( $saved['custom_css'] ) ? $saved['custom_css'] : '' ); ?></textarea>

			<h2><?php esc_html_e( 'Admin bar', 'damson-website-design' ); ?></h2>
			<p>
				<label>
					<input type="checkbox" name="<?php echo esc_attr( DWD_SETTINGS_OPTION ); ?>[hide_admin_bar_node]" value="1" <?php checked( ! empty( $saved['hide_admin_bar_node'] ) ); ?> />
					<?php esc_html_e( 'Hide the "Damson support" link in the admin bar', 'damson-website-design' ); ?>
				</label>
			</p>

			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}

/**
 * The :root block and custom CSS, as one string.
 *
 * @return string
 */
function dwd_settings_css() {
	$saved = dwd_get_settings();
	$vars  = '';
	foreach ( $saved as $key => $value ) {
		if ( 'custom_css' === $key || 'hide_admin_bar_node' === $key ) {
			continue;
		}
		$clean = dwd_clean_value( $key, $value );
		if ( '' !== $clean ) {
			$vars .= '--dwd-' . $key . ':' . $clean . ';';
		}
	}
	$css = '' === $vars ? '' : ':root{' . $vars . '}';
	if ( ! empty( $saved['custom_css'] ) ) {
		$css .= "\n" . wp_strip_all_tags( $saved['custom_css'] );
	}
	return $css;
}

/**
 * Print the settings after the child stylesheet.
 *
 * @param string $child_handle Handle of the stylesheet that holds style.css.
 */
function dwd_enqueue_settings_css( $child_handle ) {
	$css = dwd_settings_css();
	if ( '' === $css ) {
		return;
	}
	wp_register_style( 'dwd-settings', false, array( $child_handle ), DWD_THEME_VERSION );
	wp_enqueue_style( 'dwd-settings' );
	wp_add_inline_style( 'dwd-settings', $css );
}
