<?php
/**
 * Theme setup: translations and small head clean-up.
 *
 * @package Damson_Website_Design
 */

defined( 'ABSPATH' ) || exit;

/**
 * Load translations from /languages.
 */
function dwd_load_textdomain() {
	load_child_theme_textdomain( 'damson-website-design', DWD_THEME_DIR . '/languages' );
}
add_action( 'after_setup_theme', 'dwd_load_textdomain' );

/**
 * Remove the WordPress version from the page head and feeds.
 * Cosmetic only: it does not change how the site works.
 */
remove_action( 'wp_head', 'wp_generator' );
add_filter( 'the_generator', '__return_empty_string' );
