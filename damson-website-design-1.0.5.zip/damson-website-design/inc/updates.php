<?php
/**
 * Updates from a public metadata file via the bundled Plugin Update Checker library.
 *
 * Sites need no token and no wp-config.php change. This file never throws.
 *
 * @package Damson_Website_Design
 */

defined( 'ABSPATH' ) || exit;

function dwd_boot_updater() {
	$lib = DWD_THEME_DIR . '/inc/lib/plugin-update-checker/plugin-update-checker.php';
	if ( ! file_exists( $lib ) ) {
		return;
	}
	try {
		require_once $lib;
		\YahnisElsts\PluginUpdateChecker\v6\PucFactory::buildUpdateChecker(
			'https://matthewdavis97.github.io/damson-releases/damson-website-design.json',
			DWD_THEME_DIR . '/functions.php',
			'damson-website-design'
		);
	} catch ( \Throwable $e ) {
		return;
	}
}
dwd_boot_updater();
