=== Damson Website Design ===
Contributors: damsonwebsitedesign
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.5
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Divi child theme by Damson Website Design. A clean, neutral base for client websites built and managed by Damson.

== Description ==

This is the child theme Damson uses as the starting point for client sites built with Divi. It keeps the client's own branding on the front end and adds a light "managed by Damson" touch in the WordPress admin.

What's included:

* Correct stylesheet loading for Divi 4. Divi loads the child style.css itself on newer versions; the theme detects this, so nothing loads twice, and versions the file by its modified time so edits show up straight away.
* Per-client settings (colours, spacing, header height, custom CSS) on Appearance > Damson Settings, stored in the database so theme updates never overwrite them. Neutral defaults; Damson colours are not applied to the front end.
* Small Divi fixes: scrollable mobile menu with bigger tap targets, anchor links that clear a fixed header, no iOS zoom on form fields, image overflow fixes, long-word wrapping.
* Accessibility: visible keyboard focus rings (including Divi buttons) and full support for "reduce motion", including Divi entrance animations and parallax.
* Helper classes for the Divi CSS Class field (see below).
* Admin footer: "Website managed by Damson Website Design" with a link to the Client Portal.
* Dashboard widget "Damson Website Design" with links to the Client Portal, Hosting Portal and website, plus a few quick tips for clients. The "Get support" button opens the Support page (https://damsonwebsitedesign.co.uk/support/).
* A small "Damson support" link in the admin bar for logged-in editors.
* A one-off, dismissible notice for administrators if the Damson Login plugin is not active. The plugin is not bundled.
* Removes the WordPress version number from the page head. No other behaviour changes; security is left to your security plugin.

Privacy: the only external request is a periodic update check against a public metadata file. No tracking, no cookies.

== Installation ==

1. Install and activate the Divi parent theme first (Appearance > Themes > Add New > Upload Theme, choose Divi.zip). The folder must be called "Divi".
2. Upload this child theme: Appearance > Themes > Add New > Upload Theme, choose damson-website-design.zip, then Install Now.
3. Activate "Damson Website Design". Divi stays installed; keep it updated as normal.
4. Divi Theme Options, Theme Builder layouts and Customiser settings are stored per theme. If the site already had Divi active, re-check Divi > Theme Options and Appearance > Customise after switching, or export/import them via Divi > Theme Options > Portability.

== Customising per client ==

Per-site values are stored in the database and survive theme updates. Don't edit style.css or functions.php for them.

1. Colours, spacing, header height, line lengths and line heights: Appearance > Damson Settings. Match Primary and Accent to the colours in Divi > Theme Options so everything agrees. Leave a field empty to use the default.
2. Fixed header height: set "Header height" on the same page so #anchor links land in the right place (0px if the header isn't fixed).
3. Client CSS: Appearance > Damson Settings > Custom CSS (or Divi > Theme Options > Custom CSS).
4. Client PHP: use a Code Snippets plugin or a small site plugin, not this theme's files (an update replaces them).
5. Support links: change them with the dwd_support_links filter in that snippet, for example:

    add_filter( 'dwd_support_links', function ( $links ) {
        $links[] = array( 'url' => 'https://example.com/', 'label' => 'Example', 'desc' => 'Short description.' );
        return $links;
    } );

6. Hide the admin bar link on a site: tick the box on Appearance > Damson Settings (or use add_filter( 'dwd_show_admin_bar_node', '__return_false' ); in a snippet).

Helper classes (Divi > Advanced > CSS Class):

* Text: dwd-measure (comfortable line length), dwd-center, dwd-muted, dwd-lead, dwd-balance, dwd-eyebrow
* Colour: dwd-text-primary, dwd-text-accent, dwd-surface-alt
* Spacing: dwd-pad-sm, dwd-pad-md, dwd-pad-lg, dwd-mb-0, dwd-mb-sm, dwd-mb-md
* Layout: dwd-card, dwd-rounded, dwd-equal-height (on a Row)
* Visibility: dwd-hide-phone, dwd-hide-tablet, dwd-hide-desktop

== Files ==

* style.css: theme header, default settings, base CSS, Divi fixes and helpers
* functions.php: constants and includes
* inc/setup.php: translations, version meta removal
* inc/settings.php: Appearance > Damson Settings (per-site values stored in the database)
* inc/enqueue.php: stylesheet loading
* inc/admin-branding.php: admin footer, dashboard widget, admin bar link
* inc/notices.php: Damson Login suggestion notice
* inc/updates.php: public update checker (no token, no wp-config.php change)
* inc/lib/plugin-update-checker/: bundled update checker library (MIT)
* assets/css/admin.css: dashboard widget styles
* assets/img/: Damson logo used in the dashboard widget
* languages/damson-website-design.pot: translation template

== Changelog ==

= 1.0.5 =
* Per-site settings moved out of style.css. Colours, spacing, header height, line lengths, custom CSS and the admin bar toggle now live in Appearance > Damson Settings and are stored in the database, so theme updates no longer overwrite them. Saved values print as a :root block after the child stylesheet. If you changed colours in style.css on 1.0.4 or earlier, this one update replaces that file: re-enter the colours in Damson Settings afterwards. From 1.0.5 onwards updates keep every setting.

= 1.0.4 =
* Updates no longer need a GitHub token or a wp-config.php change. The theme checks a public metadata file and shows "Update available" under Appearance > Themes. No design changes.

= 1.0.3 =
* Updates from GitHub: the theme checks matthewdavis97/damson-child-theme for new releases (Plugin Update Checker 6.0, bundled in inc/lib/) and shows "Update available" under Appearance > Themes. Private repo: add define( 'DAMSON_UPDATES_TOKEN', '...' ); to wp-config.php. Without the token it quietly finds nothing. No design changes.

= 1.0.2 =
* The dashboard widget's "Get support" button now opens the Support page, https://damsonwebsitedesign.co.uk/support/ (new DWD_URL_SUPPORT constant in functions.php).

= 1.0.1 =
* Theme screenshot and dashboard widget now use the master Damson logo (22 Nov 2026).

= 1.0.0 =
* First release.
