<?php
/**
 * Damson Website Design: Divi child theme.
 *
 * Keep this file small. Features live in /inc so they are easy to find,
 * switch off, or extend per client.
 *
 * @package Damson_Website_Design
 */

defined( 'ABSPATH' ) || exit;

define( 'DWD_THEME_VERSION', '1.0.4' );
define( 'DWD_THEME_DIR', get_stylesheet_directory() );
define( 'DWD_THEME_URI', get_stylesheet_directory_uri() );

define( 'DWD_URL_WEBSITE', 'https://damsonwebsitedesign.co.uk/' );
define( 'DWD_URL_CLIENT_PORTAL', 'https://portal.damsonwebsitedesign.co.uk/' );
define( 'DWD_URL_HOSTING_PORTAL', 'https://hosting.damsonwebsitedesign.co.uk/' );
define( 'DWD_URL_SUPPORT', 'https://damsonwebsitedesign.co.uk/support/' );

require_once DWD_THEME_DIR . '/inc/setup.php';
require_once DWD_THEME_DIR . '/inc/enqueue.php';
require_once DWD_THEME_DIR . '/inc/updates.php';

require_once DWD_THEME_DIR . '/inc/admin-branding.php';

if ( is_admin() ) {
	require_once DWD_THEME_DIR . '/inc/notices.php';
}

/*
 * Client-specific PHP goes below this line, or in a new file in /inc.
 */
